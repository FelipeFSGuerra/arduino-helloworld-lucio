import 'package:flutter/material.dart'; //Importa o pacote de widgets do Flutter.
import 'package:http/http.dart' as http; // Importa o pacote HTTP para fazer solicitações HTTP.
import 'dart:js' as js; //Importa o pacote JS para interagir com o JavaScript

void main() //ponto de entrada do app
{
  runApp(HelloWorld());
}

class HelloWorld extends StatelessWidget
{
    final String serverIp = "10.0.3.118"; // final define um atributo ou variável
                               // cujo conteúdo não se altera durante a execução

    Widget build(BuildContext context)
    {
      return MaterialApp( //  O widget raiz do aplicativo que fornece temas e navegação.
        home: Scaffold( //Um widget de layout padrão para a estrutura visual básica de um aplicativo.
          appBar: AppBar(
            title: Text('App Hello World'),
          ),
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              
              children: <Widget>[
                ElevatedButton(
                  onPressed: () => sendCommand('/helloworld'),
                  child: Text('Mande um "Hello World!"'),
                ),
              ],
            ),
          ),
        )
       );
    } // fim do método build
    
    void sendCommand(String command) async {
    final url = Uri.http(serverIp, command);
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        print('Comando enviado com sucesso');
      } else {
        print('Erro ao enviar comando');
      }
    } catch (e) {
      print('Erro: $e');
    }
  }
} 




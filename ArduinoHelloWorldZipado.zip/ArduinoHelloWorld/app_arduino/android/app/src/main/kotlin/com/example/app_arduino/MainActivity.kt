package com.example.app_arduino

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
